package com.example.vizsga_02_10_23_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Vizsga021023BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
