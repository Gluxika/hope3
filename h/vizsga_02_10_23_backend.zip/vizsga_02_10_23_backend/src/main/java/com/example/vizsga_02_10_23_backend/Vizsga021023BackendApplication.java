package com.example.vizsga_02_10_23_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Vizsga021023BackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(Vizsga021023BackendApplication.class, args);
	}

}
